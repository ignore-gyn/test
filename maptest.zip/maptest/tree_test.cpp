#include <limits.h>
#include <iostream>
#include <iterator>
#include <sstream>
#include <vector>

#define REPEAT 1
#define DEPTH 50
#define WIDTH 5
#define KEY_STRING "5,5,5,5,5,5,5,4"

std::string get_vector_string(std::vector<unsigned int> v) {
  std::ostringstream o;
  std::copy(v.begin(), v.end(), std::ostream_iterator<int>(o, ","));
  std::string s = o.str();
  s.pop_back();

  return s;
  //   std::cout << s << std::endl;
}

void search_vector_to_string() {
  std::vector<unsigned int> v;
  unsigned int is_found = 0;

  for (unsigned int i = 0; i < DEPTH; i++) {
    v.push_back(0);
    for (unsigned int j = 1; j <= WIDTH; j++) {
      v[i] = j;

      if (get_vector_string(v) == KEY_STRING) {
        is_found++;
      }
    }
  }
  // std::cout << "found: " << is_found << std::endl;
}

void search_vector_to_vector(const std::vector<unsigned int>& key) {
  std::vector<unsigned int> v;
  unsigned int is_found = 0;

  for (unsigned int i = 0; i < DEPTH; i++) {
    v.push_back(0);
    for (unsigned int j = 1; j <= WIDTH; j++) {
      v[i] = j;

      // if (v.size() == key.size() && v == key) {
      if (v == key) {
        is_found++;
      }
    }
  }
  // std::cout << "found: " << is_found << std::endl;
}

std::string get_array_string(const unsigned int* arr, unsigned int len) {
  std::ostringstream o;

  for (int i = 0; i < len; i++) {
    o << arr[i] << ",";
  }
  std::string s = o.str();
  s.pop_back();

  // std::cout << s << std::endl;
  return s;
}

void search_array(const unsigned int* key_arr) {
  unsigned int a[DEPTH] = {};
  unsigned int is_found = 0;

  size_t target_len = 8;

  for (unsigned int i = 0; i < DEPTH; i++) {
    for (unsigned int j = 1; j <= WIDTH; j++) {
      a[i] = j;

      if (i == target_len) {
        unsigned int k;
        for (k = 0; k < i; k++) {
          if (key_arr[k] != a[k] && key_arr[k] != 0) {
            break;
          }
        }
        if (k == i) {
          is_found++;
        }
      }
    }
  }
  // std::cout << "found: " << is_found << std::endl;
}

void search_array_to_string() {
  unsigned int a[DEPTH] = {};
  unsigned int is_found = 0;

  size_t target_len = 8;

  for (unsigned int i = 0; i < DEPTH; i++) {
    for (unsigned int j = 1; j <= WIDTH; j++) {
      a[i] = j;

      if (get_array_string(a, i+1) == KEY_STRING) {
        is_found++;
      }
    }
  }
  std::cout << "found: " << is_found << std::endl;
}

int main(int argc, const char* argv[]) {
  clock_t start, end;

  std::vector<unsigned int> key = {5, 5, 5, 5, 5, 5, 5, 4};
  const unsigned int key_arr[] = {5, 5, 5, 5, 5, 5, 5, 0};

  // vector to string
  start = clock();

  for (unsigned int i = 0; i < REPEAT; i++) {
    search_vector_to_string();
  }

  end = clock();
  std::cout << "time=" << end - start << std::endl;

  // vector to vector
  start = clock();

  for (unsigned int i = 0; i < REPEAT; i++) {
    search_vector_to_vector(key);
  }

  end = clock();
  std::cout << "time=" << end - start << std::endl;

  // array
  start = clock();

  for (unsigned int i = 0; i < REPEAT; i++) {
    search_array(key_arr);
  }

  end = clock();
  std::cout << "time=" << end - start << std::endl;

  // array to string
  start = clock();

  for (unsigned int i = 0; i < REPEAT; i++) {
    search_array_to_string();
  }

  end = clock();
  std::cout << "time=" << end - start << std::endl;
}