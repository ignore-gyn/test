#include <limits.h>
#include <iostream>
#include <map>
#include <sstream>
#include <string>
#include <time.h>
#include <unordered_map>

#define REPEAT USHRT_MAX
#define MAP_SIZE 10000
#define KEY_STRING "hogefugatest99990"

void search_unordered_map() {
  std::unordered_map<std::string, std::string> um;
  std::string o;

  for (int i = 0; i < MAP_SIZE; i++) {
    std::ostringstream key;
    std::ostringstream val;
    key << "hogefugatest" << i;
    val << i;
    um[key.str()] = val.str();
  }

  unsigned int is_found = 0;
  for (unsigned int i = 0; i < REPEAT; i++) {
    try {
      o = um.at(KEY_STRING);
      is_found++;
    } catch (std::out_of_range) {
    }
  }
  std::cout << "[" << o << "] is found: " << is_found << std::endl;
}

void search_unordered_map_find() {
  std::map<std::string, std::string> m;
  std::string o;

  for (int i = 0; i < MAP_SIZE; i++) {
    std::ostringstream key;
    std::ostringstream val;
    key << "hogefugatest" << i;
    val << i;
    //m[key.str()] = val.str();
    m.emplace(key.str(),val.str());
  }

  unsigned int is_found = 0;
  for (unsigned int i = 0; i < REPEAT; i++) {
    std::map<std::string, std::string>::iterator itr = m.find(KEY_STRING);
    if (itr != m.end()) {
      o = itr->second;
      is_found++;
    }
  }
  std::cout << "[" << o << "] is found: " << is_found << std::endl;
}

void search_unordered_map_at() {
  std::map<std::string, std::string> m;
  std::string o;

  for (int i = 0; i < MAP_SIZE; i++) {
    std::ostringstream key;
    std::ostringstream val;
    key << "hogefugatest" << i;
    val << i;
    m[key.str()] = val.str();
  }

  unsigned int is_found = 0;
  for (unsigned int i = 0; i < REPEAT; i++) {
    try {
      o = m.at(KEY_STRING);
      is_found++;
    } catch (std::out_of_range) {
    }
  }
  std::cout << "[" << o << "] is found: " << is_found << std::endl;
}


int main(int argc, char const *argv[]) {
  clock_t start, end;

  std::map<std::string, std::string> m;

  // unordered_map: create, get by []
  start = clock();

  search_unordered_map();

  end = clock();
  std::cout << "time=" << end-start << std::endl;

  // map: create, get by find then []
  start = clock();

  search_unordered_map_find();

  end = clock();
  std::cout << "time=" << end-start << std::endl;

  // map: create, get at (catch exception)
  start = clock();

  search_unordered_map_at();

  end = clock();
  std::cout << "time=" << end-start << std::endl;



  // if (itr == m.end()) {
  //   std::cout << "[map] Not Found." << std::endl;
  // } else {
  //   std::cout << "[map] Found." << std::endl;
  // }
}