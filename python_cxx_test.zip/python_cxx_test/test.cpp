#include "test_clib.hpp"

int main(int argc, char* argv[]) {

    hello();
}