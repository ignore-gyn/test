#include "test_clib.hpp"
// #include <iostream>
// #include <sstream>
// #include <string>

#include <stdio.h>

void hello(void) {
  // std::cout << "Hello, world" << std::endl;
  printf("Hello, world\n");
}

void output(MSGDATA* msg) {
  // std::ostringstream o;

  // o << "stream=" << msg.stream;
  // o << ", function=" << msg.function << std::endl;
  // o << "message=" << msg.message << std::endl;

  // return o.str().c_str();

  printf("stream=%d, function=%d\nmessage=%s\n", msg->stream, msg->function, msg->message);
  
  return;
}

long add(long a, long b) { return a + b; }