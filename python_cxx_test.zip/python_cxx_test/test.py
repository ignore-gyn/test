# -*- coding: utf-8 -*-
import os
import test_clib_wrapper

IN = 0
OUT = 1

S2_END = 0
S2_A = 16
S2_U4 = 26

CONNECTID = 1


def SendMessage():
    msg = test_clib_wrapper.SdrMessageWrapper(OUT)
    msg.ItemOutput_A("hello")
    msg.sendPrimary()


def DecodeMessage(msg):
    # item_type = msg.next
    # while item_type == S2_END:
    #     if item_type == S2_A:
    #         data = test_clib_wrapper.ItemInput_A(item_type)
    #         print '<A "%s">' % data
    #     elif item_type == S2_U4:
    #         data = test_clib_wrapper.ItemInput_U4(item_type)
    #         print '<U4 %d>' % data

    data = msg.ItemInput_A()
    print '<A "%s">' % data
    data = msg.ItemInput_U4()
    print '<U4 %d>' % data[0]


def main():
    # os.environ["LD_LIBRARY_PATH"] = "/home/ignore/python_cxx_test"

    test_clib_wrapper.hellowrap()

    # while True:
    #     # t = test_clib_wrapper.Transaction()
    #     status = test_clib_wrapper.SdrIdPollWrapper(CONNECTID)#, t)
    #     if status == 1:
    #         msg = t.incoming_msg
    #         DecodeMessage(msg)
    #         break

    msg = test_clib_wrapper.SdrMessageWrapper(IN)
    DecodeMessage(msg)


if __name__ == "__main__":
    main()
