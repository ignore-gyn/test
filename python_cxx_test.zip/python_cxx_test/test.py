# -*- coding: utf-8 -*-
import test_clib_wrapper

def main():
    test_clib_wrapper.hello()

    test_clib_wrapper.hellowrap()
    test_clib_wrapper.outputwrap(123, 4, ":P hello")

if __name__ == "__main__":
    main()

