#include <stdio.h>
#include <boost/python.hpp>
#include "test_clib.hpp"

void hellowrap() {
  printf("This is Wrapper!!! :D\n");
  hello();
}

void outputwrap(unsigned int stream, unsigned int function, const char* data) {
  MSGDATA msg;
  msg.stream = stream;
  msg.function = function;
  msg.message = data;

  output(&msg);
}


BOOST_PYTHON_MODULE(test_clib_wrapper) {
  boost::python::def("hello", &hello);
  boost::python::def("hellowrap", &hellowrap);

  boost::python::def("output", &output);
  boost::python::def("outputwrap", &outputwrap);

  boost::python::def("add", &add);
}