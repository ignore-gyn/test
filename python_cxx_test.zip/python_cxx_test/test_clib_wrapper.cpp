#include <stdio.h>
#include <boost/python.hpp>
#include "test_clib.hpp"

using namespace boost::python;

#define CONNECTID 1
#define IN 0
#define OUT 1
#define S_POLL 1

#define S2_A 16
#define S2_U4 26

typedef long SDRLENGTH;
typedef unsigned short SDRTKT;

typedef struct {
  unsigned int stream;
  unsigned int function;
  unsigned int wbit;
  unsigned char* buffer;
  SDRLENGTH length;
  int next;
} SDRMSG;

/* SDR */
int SdrIdPoll(unsigned short connectId, SDRTKT* tkt, SDRMSG* msg) { return 1; }

SDRLENGTH SdrItemInitI(SDRMSG* msg) { return 1; }

SDRLENGTH SdrItemInput(SDRMSG* msg, int type, void* buffer, SDRLENGTH count) {
  if (type == S2_A) {
    buffer = (const char*)"abc";
    return 3;
  } else if (type == S2_U4) {
    ((long*)buffer)[0] = (long)100;
    return 1;
  }
  return 0;
}

SDRLENGTH SdrItemInitO(SDRMSG* msg) { return 1; }

// int SdrRequest(unsigned short connectId, SDRMSG* msg, SDRTKT* tkt) {
//   printf("Message is sent\n");
//   *tkt = 100;
// }

/* Transaction Class */
class Transaction {
 public:
  Transaction(SDRTKT tkt, SDRMSG msg);

 private:
  int* incoming_msg;
};

Transaction::Transaction(SDRTKT tkt, SDRMSG msg) {}

/* SdrMessageWrapper Class */
class SdrMessageWrapper {
 public:
  SdrMessageWrapper(int in_out);

  // SDRLENGTH ItemOutput_A(char* buffer, SDRLENGTH length);
  // SDRLENGTH ItemOutput_U4(long buffer, SDRLENGTH length);

  boost::python::list ItemInput_A();
  boost::python::list ItemInput_U4();

 private:
  SDRMSG msg;
  unsigned int stream;
  unsigned int function;
  unsigned int wbit;
};

SdrMessageWrapper::SdrMessageWrapper(int in_out) {
  if (in_out == IN) {
    SdrItemInitI(&msg);
  } else {
    SdrItemInitO(&msg);
  }
}

// SDRLENGTH SdrMessageWrapper::ItemOutput_A(char* buffer, SDRLENGTH length) {
//   return SdrItemOutput(&msg, S2_A, buffer, length);
// }
// SDRLENGTH SdrMessageWrapper::ItemOutput_U4(long buffer, SDRLENGTH length) {
//   return SdrItemOutput(&msg, S2_U4, buffer, length);

//   static bpy::list py_search(bpy::tuple start, bpy::tuple goal) {
//     // optionally check that start and goal have the required
//     // size of 2 using bpy::len()
//     std::array<double, 2> _start = {bpy::extract<double>(start[0]),
//                                     bpy::extract<double>(start[1])};
//     std::array<double, 2> _goal = {bpy::extract<double>(goal[0]),
//                                    bpy::extract<double>(goal[1])};
//     std::vector<std::array<double, 2>> cxx_retval = search(_start, _goal);
//   }
// }
#define MAX_ITEM_LEN 1000
boost::python::list SdrMessageWrapper::ItemInput_A() {
  char val[MAX_ITEM_LEN];
  SDRLENGTH len = SdrItemInput(&msg, S2_A, val, MAX_ITEM_LEN);

  boost::python::list retval;
  for (int i = 0; i < len; i++) {
    retval.append(val[i]);
  }
  return retval;
}
boost::python::list SdrMessageWrapper::ItemInput_U4() {
  long val[MAX_ITEM_LEN];
  SDRLENGTH len = SdrItemInput(&msg, S2_U4, &val, MAX_ITEM_LEN);

  boost::python::list retval;
  for (int i = 0; i < len; i++) {
    retval.append(val[i]);
  }
  return retval;
}

/* Wrapper functions */
int SdrIdPollWrapper(unsigned short connectId, Transaction& t) {
  SDRTKT tkt;
  SDRMSG msg;

  int status = SdrIdPoll(connectId, &tkt, &msg);
  if (status == S_POLL) {
    t = Transaction(tkt, msg);
  }
  return status;
}

void hellowrap() {
  printf("This is Wrapper!!! :D\n");
  hello();
}

void outputwrap(unsigned int stream, unsigned int function, const char* data) {
  MSGDATA msg;
  msg.stream = stream;
  msg.function = function;
  msg.message = data;

  output(&msg);
}

BOOST_PYTHON_MODULE(test_clib_wrapper) {
  // def("hello", &hello);
  def("hellowrap", &hellowrap);

  class_<SdrMessageWrapper>("SdrMessageWrapper", init<int>())
      .def("ItemInput_A", &SdrMessageWrapper::ItemInput_A)
      .def("ItemInput_U4", &SdrMessageWrapper::ItemInput_U4);
}