// #include <string>

typedef struct {
    unsigned int stream;
    unsigned int function;
    const char* message;
    long msg_len;
} MSGDATA;

void hello(void);
void output(MSGDATA* msg);
long add(long, long);
