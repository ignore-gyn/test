var app = angular.module('myApp', ["ui.bootstrap"]);

app.controller('AppController', function ($scope) {
    $scope.acl = [
        { ID: "CROWD_S", AssignedRole: "Role_A", Privileges: "PrivA<br>PrivB" },
        { ID: "Role_A", AssignedRole: "-", Privileges: "PrivA\nPrivB" },
        { ID: "Role_B", AssignedRole: "-", Privileges: "PrivA\nPrivB" },
        { ID: "CROWD_T", AssignedRole: "-", Privileges: "PrivA<br>PrivB" },
    ];

    $scope.selectedRow = -1;
    $scope.rowHighlited = function (idx) {
        if ($scope.selectedRow === idx) {
            $scope.selectedRow = -1;
        } else {
            $scope.selectedRow = idx;
        }
    };


});

