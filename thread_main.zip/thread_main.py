import time
import Queue
import thread_test


def main():
    thread_test.init()

    time.sleep(5)
    establish_session()
    time.sleep(5)
    for i in range(len(thread_test.ThreadPool)):
        thread_test.TaskQueue.put("hello")

    while not thread_test.f_is_stop:
        pass

    print "Exit main()"


def hello():
    time.sleep(3)
    print "Hello ;D"


def establish_session():
    reply_queue = Queue.Queue()
    thread_test.send_message("S1F13", reply_queue)
    reply = reply_queue.get()
    if reply == "S1F14":
        print "Established session"
    else:
        print "Failed to establish session"
    del reply_queue


if __name__ == "__main__":
    print thread_test.GlobalSymbols
    main()
