import Queue
import signal
import threading
import time

TaskQueue = Queue.Queue()
ThreadPool = []

poll_thread = None
GlobalSymbols = globals()
f_is_stop = False


def signal_handler(signum, frame):
    if not f_is_stop:
        print "Received SIGNAL. Exit program."
        term()


def user_input_handler():
    global TaskQueue

    while not f_is_stop:
        user_input = raw_input()
        if user_input == "q":
            term()
        else:
            TaskQueue.put(user_input)


class ThreadBase(threading.Thread):
    def __init__(self, name="PollThread"):
        self._stopevent = threading.Event()
        self._sleep_period = 1.0

        threading.Thread.__init__(self, name=name)

    def run(self):
        print "Start %s" % self.getName()

        while not self._stopevent.isSet():
            self.work()
            self._stopevent.wait(self._sleep_period)

    def join(self, timeout=None):
        print "Stopping %s" % self.getName()

        self._stopevent.set()
        threading.Thread.join(self, timeout)

        print "Stopped %s" % self.getName()

    def work():
        pass


class PollThread(ThreadBase):
    def __init__(self, name="PollThread"):
        self._count = 0
        super(PollThread, self).__init__("PollThread")

    def work(self):
        dummy_remote_worker(self._count, "")
        self._count += 1


def send_message(sf, reply_queue):
    reply_queue = Queue.Queue()
    thread_test.send_message("S1F13", reply_queue)
    reply = reply_queue.get()

    reply_queue.put(dummy_remote_worker(0, sf))


def worker_thread(thread_name):
    print "Start Thread=%s" % thread_name
    while True:
        task = TaskQueue.get()
        print "[Work %s]" % thread_name
        if task is None:
            break
        elif callable(task):
            task()
        elif isinstance(task, str):
            if GlobalSymbols.get(task) and callable(eval(task)):
                eval(task)()
            else:
                print task
        else:
            print "Illegal input is passed"

    print "Stop Thread=%s" % thread_name


def start_thread_pool(size_of_threadpool=5, is_daemon=True):
    for i in range(size_of_threadpool):
        new_thread = threading.Thread(
            target=worker_thread,
            args=["Thread%d" % i])
        new_thread.setDaemon(is_daemon)
        ThreadPool.append(new_thread)
        new_thread.start()


def stop_thread_pool():
    for i in range(len(ThreadPool)):
        TaskQueue.put(None)
    for t in ThreadPool:
        t.join()
    del ThreadPool[:]


def init():
    global poll_thread

    signal.signal(signal.SIGTERM, signal_handler)
    signal.signal(signal.SIGINT, signal_handler)

    poll_thread = PollThread()
    poll_thread.start()

    new_thread = threading.Thread(target=user_input_handler)
    new_thread.setDaemon(True)
    new_thread.start()

    start_thread_pool()


def term():
    global f_is_stop
    if f_is_stop:
        return

    f_is_stop = True

    poll_thread.join()
    stop_thread_pool()


# if __name__ == "__main__":
#     main()

def dummy_remote_worker(tkt, sf):
    if sf == "S1F13":
        return "S1F14"
    elif tkt % 30 == 0:
        return "S2F%d" % tkt
    else:
        return None
